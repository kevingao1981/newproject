
loc = function(file, dir = root) {
  
  path = paste0(dir, "/", file)
  
  path
  
}

str_format = function(x, y = 'Data/\\1') {
  
  # Python-like string input format function
  # str_format('Data/\\1/VoC_to\\2.xlsx', c('Archived', 'Apr16'))
  # "Data/Archived/VoC_toApr16.xlsx"
  
  string = paste0("(", x, ")", collapse = "")
  pat = paste0(rep("\\((.*?)\\)", length(x)), collapse = "")
  gsub(pat, y, string, perl = TRUE)
  
}


query = substitute