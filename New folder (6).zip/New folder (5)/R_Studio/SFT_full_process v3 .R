##############################################################################################;
#                                                                                            #;
# Program:         Sales Force Complaints Classification Full Process                        #;
# Project:                                                                                   #;
# Technician:      Max Driscoll O'Keefe                                                      #;
# Requestor:       N/A                                                                       #;
# Written:         August 2018                                                               #;
# Description:     Query data and create a single temporatory file for SFT Complaints/Issues #;
#                   to run; This script is worked as a master control sheet.                 #;
#                                                                                            #;
# KeyWords:        ETL, SalesForce                                                           #;
# Inputs:          z3_Raw_SFT_case                                                           #;
#                                                                                            #;
# Outputs:         Z0_strategy_TABLE                                                         #;
#                                                                                            #;
#                                                                                            #;
##############################################################################################;
# Amendment History                                                                          #;
##############################################################################################;
#                                                                                            #;
# 27/08/2018 Max Driscoll O'Keefe     Edited script from VoC to target sft_case descriptions #;
##############################################################################################;

options( java.parameters = "-Xmx32g" )
library(qdap)
library(tm)
library(plyr)
library(dplyr)
library(readr)
library(stringr)
library(rJava)
library(RWeka)
library(StanfordCoreNLP)
library(reshape2)
library(tidyr)
library(openxlsx)
library(readxl)
library(lubridate)
library(zoo)
#Set up your working directory
library(RODBC)setwd("/etc_cloudera/user_home/768754/Work/R/SFT_Text_Analysis")

#0.1 connect using Impala ODBC and extract SalesForce Issue/Complaint case data
Impala <- RODBC::odbcConnect("Impala")
source('SFT_TableImport.R')

library(sparklyr)
library(DBI)

#0.2 Environment Set Up
source('ddt.R')
source('cleaning.R')
source('utilise.R')
#source('pimp.R')

#0.3 Parameter
print(getwd())
mapping_code = "4PClass/summarise5.csv"
kwd_dict = "4PClass/modifyList6.csv"

#0.4 Change to the correct database when it is ready
output_file = "Sft_case_textanalyticsthemes"
output_database = "z0_strategy"
output_logic = TRUE

#0.5 Text analytics
print("The 4P text analytics process is running ...")
source('Classification4Pv3.R')
print('Transformer completed')


##Export the table to Hadoop
source(Export_Hadoop)

###############################################################################################################
#The export will not resolve right away. In order to solve this, go to HUE and type:                          #
#  "INVALIDATE METADATA z0_strategy.'TableName'"                                                              #
###############################################################################################################


#Check the table has succesfully been expoted by trying to pull it back into R.
IsItInThere <- DBI::dbGetQuery(sc , "SELECT * FROM z0_strategy.YOURTABLE")


#Clear the workspace
rm(list = ls())
