##Export the modified table with Text Analytics Fields to Hadoop. If the table already exists, this will overwrite it
library(sparklyr)
library(DBI)

#Set up the connection
Sys.setenv("SPARK_MEM" = "4g")
conf <- spark_config()
conf$spark.kryoserializer.buffer.max = "1G"
conf$spark.driver.memory <- "8g"
conf$spark.yarn.principal = "768754@BNZNAG.NZ.THENATIONAL.COM"
conf$spark.yarn.keytab = "/etc_cloudera/user_home/768754/768754.keytab"
sc <- spark_connect(master = "yarn-client", version = "2.2.0", config = conf)


#Export the table
tabletowrite <- SFT_Export_Base2
DBI::dbGetQuery(sc, "DROP TABLE IF EXISTS z0_strategy.YOURTABLE")  
DBI::dbWriteTable(sc, "z0_strategy.YOURTABLE", tabletowrite)

