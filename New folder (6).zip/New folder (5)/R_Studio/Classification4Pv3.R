
  dat = rdf_sft_cases
  
  dat.rating = as.data.frame(dat) %>% 
    select(casenumber, description, customer_number__c, customer_segment_md, 
           category__c, case_type__c, days_to_resolve__c, priority, cost_to_resolve__c)  

  
  dat.verbatim = as.data.frame(dat) %>%
    select(casenumber, description)
  

  dat.verbatim$BNZ_rating = dat.verbatim$description
  is.na<- (dat.verbatim$BNZ_rating[!is.na(dat.verbatim$description)])
  #####################################################################################################################
  
  
  # load regular expression dictionary
  reg0= read.csv(kwd_dict, header= TRUE, stringsAsFactors = FALSE,allowEscapes=TRUE)
  reg = subset(reg0, !Top.Level %in% c("NoResponse", "feel", "CANCEL"))
  repl = reg$Sub.Level
  mod = reg$Rex
  perl.t = reg$perl

    
  # simple cleaning of the verbatim
  # This is essentially expand any "don't" pattern into "do not"
  # Thus, we can use "not" in the regular expression
  dat.verbatim = dat.verbatim %>% 
    join(., dat.rating, by="casenumber", type="inner", match="all") %>%
    filter(!is.na(BNZ_rating)) 
  
  string = dat.verbatim$BNZ_rating
  #    string = dat.verbatim$description
  
  #  soft_remove = as.integer(nchar(as.character(dat.verbatim$description)) <= 5)
  soft_remove = as.integer(nchar(as.character(dat.verbatim$BNZ_rating)) <= 5)
  
  
  # Testing: changing and to ,
  string = gsub("(\\band\\b)(?=([^[:punct:]]|$){15})", ",", string, perl = TRUE)
  string = paste0(string, ". ", dat.verbatim$BNZ_rating)
  # using regular expression pattern to replace keywords variation into one form
  # for example, "good", "happy", "great" are thus transformed in to "positive" in the text. 
  for(i in 1:length(mod)){ 
    string <- gsub(paste0("\\b(",mod[i], ")\\b"),
                   #mod[i],
                   paste(" ",repl[i]," ",sep=""),
                   string,
                   ignore.case=TRUE,
                   perl = perl.t[i]) 
                  }
  
  # we now generate bag-of-word model
  # This is to calculate the keyword capture rate
  reg = subset(reg0, ! Top.Level %in% c("General", "NoResponse", "feel", "CANCEL"))
  mat1 = sapply(reg$Sub.Level, function(x) as.integer(grepl(paste0("\\b",x,"\\b"), string, ignore.case = TRUE)))
  mat2 = as.data.frame(mat1)
  
  print(sum(mat2$generalsentence))
  # before calculating capture rate we need to find non-capture group 
  noreponse_index = grep(reg0$Rex[reg0$Sub.Level == "noresponse"], dat.verbatim$BNZ_rating, ignore.case= TRUE)
  # we labeled those without keywords existing verbatim as "No Response".
  noreponse_index = noreponse_index[noreponse_index %in% which(rowSums(mat2)==0)]
  
  # only keep those keywords have been presented in the verbatim
  g1 = reg$Sub.Level
  g1 = g1[colSums(mat2)>0]
  
  # Capture Rate of dictionary
  kwd_cap = sum(rowSums(mat2)>0)/nrow(mat1)
  
  # remove zero frequency keywords column
  mat2 = mat2[, colSums(mat2)>0]
  
  # export to checking
  mat3 = mat2[,colSums(mat2)>0]
  mat3$noresponse = 0
  mat3$noresponse[noreponse_index] = 1
  mat3$noncapture = as.integer(rowSums(mat3)==0)
  
  
  # capture rate of adding noresponse and noncapture to force it to become 100%
  sum(rowSums(mat3)>0)/nrow(mat1)
  
  # define a function to generate regular expression
  # pattern of subjective + objective 
  EventHandler00 <- function(A = "proactive", B = "not|more|be") {
    
    # building pattern as B....A or A....B
    # A is objective keywords, B is subjective keywords
    
    # 1. defined pattern 
    pattern = paste0(paste0("(\\b",B,"\\b)","(?=[^,.?!|]*(\\b",A, "\\b))"),"|",
                     paste0("(\\b",A,"\\b)","(?=[^,.?!|]*(\\b",B, "\\b))")
    )
    pattern
  }
  
  # keywords combination
  # g2: sentiment keywords, subjective 
  # g3: 4P, objective
  # we construct combinations to capture "subjective + objective" pattern
  g2 = g1[ g1 %in% c("friendly", "positive", "negative", "efficiency", "noteffciency", "easy", "hard", "profession", "unprofession", "competitive", "Inadequate")]
  g3 = g1[!g1 %in% c("friendly", "positive", "negative", "efficiency", "noteffciency", "easy", "hard", "profession", "unprofession", "competitive", "Inadequate")]
  g4 = c('NotRecommend', 'generalsentence')
  com_txt2 = expand.grid(g3,g2)
  com_txt2 = rbind(data.frame(Var1 = g2, Var2 = g2), com_txt2)
  # g4 is used for single term matching a code frame.
  com_txt2 = rbind(data.frame(Var1 = g4, Var2 = g4), com_txt2)
  com_txt2 = com_txt2[, 2:1]
  colnames(com_txt2) = c("top","sub")
  com_txt_frame = as.data.frame(com_txt2)
  com_txt_frame$top = as.character(com_txt_frame$top)
  com_txt_frame$sub = as.character(com_txt_frame$sub)
  
  #browser()
  
  # Looping process to find all the subjective + objective pattern
  source_list = list()
  for (i in 1:nrow(com_txt_frame)){
    top_pattern = com_txt_frame[i,1]
    if(com_txt_frame[i,1] == com_txt_frame[i,2]) {
      
      id = as.integer(grepl(paste0("\\b", top_pattern, "\\b"), string, ignore.case = TRUE, perl = TRUE))
      com_txt_frame$freq[i] = sum(id)
      
      source_list[[i]] = id
      names(source_list)[i] = top_pattern
      
      
    }else{
      sub_pattern = com_txt_frame[i,2]
      search = EventHandler00( top_pattern, sub_pattern)
      id = as.integer(grepl(search, string, ignore.case = TRUE, perl = TRUE))
      com_txt_frame$freq[i] = sum(id)
      
      source_list[[i]] = id
      names(source_list)[i] = paste0(top_pattern, "_", sub_pattern)
      
    }
  }
  
  ## turn wide form into long form using the 'melt' function
  source_frame = as.data.frame(source_list)
  source_frame = source_frame[, colSums(source_frame)>0]
  
  mod_dat = data.frame(casenumber = dat.verbatim$casenumber, source_frame)
  mod_dat2 = melt(mod_dat, id.vars = c("casenumber"), variable.name = "Theme3")
  mod_dat2 = subset(mod_dat2, value >0)
  mod_dat2$value = NULL
  
  mod_dat2$top = gsub("(\\w+)\\_(\\w+)", "\\1", mod_dat2$Theme3)
  mod_dat2$sub = gsub("(\\w+)\\_(\\w+)", "\\2", mod_dat2$Theme3)
  
  mod_dat3 = left_join(mod_dat2, reg[, c(1,3)],by = c("sub" = "Sub.Level"))
  mod_dat3 = mutate(mod_dat3, Theme1 = Theme)
  mod_dat3$Theme = NULL
  mod_dat3 = left_join(mod_dat3, reg[, c(1,3)],by = c("top" = "Sub.Level"))
  mod_dat3 = mutate(mod_dat3, Theme2 = Theme)
  mod_dat3$Theme = NULL
  mod_dat3$Theme3 = mod_dat3$sub
  mod_dat4 = mod_dat3[, c(1, 5, 6, 2)]
  names(mod_dat4) = c("casenumber", "Theme1", "Theme2", "Theme3")
  
  # ---------------------------------------------------------------------------------
  # PREPARE THE NPS VERBATIM DATA
  # At this stage, dat is equal to wide_big. They are source data. 
  # we reload it in order to have a confident stage of the source data. 
  wide_big = dat.verbatim
  wide_big$Verbatim = wide_big$BNZ_rating
  
  # redacted
  text = wide_big$Verbatim
  
  # Any string containing numbers formatted like a date will not be changed 
  date_pattern = "\\b(\\d)(\\d)?\\/(\\d)(\\d)?\\/(\\d)(\\d)(\\d)(\\d)\\b"
  text = gsub(date_pattern,"^\\1^\\2\\/^\\3^\\4\\/^\\5^\\6^\\7^\\8", text, ignore.case= TRUE, perl = TRUE)
  time_pattern = "\\b(\\d)(\\d)?\\:(\\d)(\\d)\\b"
  text = gsub(time_pattern,"^\\1^\\2\\:^\\3^\\4", text, ignore.case= TRUE, perl = TRUE)
  
  # Any string containing numbers immediately prefaced by a dollar ($) 
  # sign will be redacted after the leftmost digit; 
  # All other strings containing numbers will be redacted completely
  text = gsub("(?<!(\\$))(?<!(\\^))(\\d)","X", text, ignore.case= TRUE, perl = TRUE)
  
  
  text = gsub("\\^(?=[\\d\\:\\/])", "", text, ignore.case= TRUE, perl = TRUE)
  
  wide_big$SFT_Verbatim = text
  
  # 170724 DHG: write the VoC redacted verbatims to Hadoop
#  SFT_redactedverbatims = wide_big[,c("casenumber", "SFT_Verbatim")]

  #Max Deleted 28th August   
# pimp(dat = 'SFT_redactedverbatims',
#     tab = 'SFT_redactedverbatims',
#       cols = '',
#       db = output_database,
#       delim = ',',
#       qchar = '"',
#       skip = 0,
#       literal = TRUE,
#       reform = '',
#       wipe = FALSE,
#       method = 'p')
  
  # Mapping code frame
  mapper = read.csv(mapping_code, header = TRUE, stringsAsFactors = FALSE)
  mapper$count = NULL
  mapper = mapper %>% filter(Soft_Delete < 1)
  
  #long_big = subset(long_big, Theme1 %in% c("Product", "Process", "Price", "People", "Other"))
  long_big = mod_dat4
  
  cnt_long = long_big %>% group_by(casenumber) %>% 
    mutate(count = n(), cnt = sum(Theme1 == Theme2), rate = count/cnt)
  
  cnt_long %>% filter(rate == 1) -> single
  
  single %>% ungroup %>% group_by(Theme1, Theme2, Theme3) %>% summarise(count = n_distinct(casenumber)) -> single
  
  # replicate a long_big data as long_big0, which has attributes casenumber, Theme1, Theme2, Theme3
  long_big0 = long_big
  long_big0$Theme1 = NULL
  long_big = left_join(long_big0, mapper, by = c("Theme2", "Theme3"))
  
  mapper2 = mapper
  
  names(mapper2) = c("Theme1.2", "Theme2", "Theme3", "Mapping2", "Soft_Delete")
  
  cnt_long %>% filter(rate == 1) %>% select(casenumber, Theme2, Theme3, rate) -> reten
  
  long_big = left_join(long_big, reten)
  long_big = long_big %>% filter(!(Theme1 == 'Partial' & is.na(rate)))
  
  # 29/01/2016 Business Rule applied
  long_big$Theme1[ long_big$Mapping == "Simple and fast process" ] = "Process"
  
  # 14/07/2016 Business Rule applied
  #long_big[long_big$Theme2 == 'Good' & long_big$Theme1 == 'Partial' , 'Theme1'] = 'People'
  long_big[long_big$Theme2 == 'Easy' & long_big$Theme1 == 'Partial', 'Theme1'] = 'Process'
  long_big[long_big$Theme2 == 'Fast' & long_big$Theme1 == 'Partial', 'Theme1'] = 'Process'
  long_big[long_big$Theme2 == 'Friendly' & long_big$Theme1 == 'Partial', 'Theme1'] = 'People'
  long_big[long_big$Theme2 == 'Helpful' & long_big$Theme1 == 'Partial', 'Theme1'] = 'People'
  long_big[long_big$Theme2 == 'Hard' & long_big$Theme1 == 'Partial', 'Theme1'] = 'Process'
  long_big[long_big$Theme2 == 'Bad' & long_big$Theme1 == 'Partial', 'Theme1'] = 'People'
  long_big[long_big$Theme2 == 'Slow' & long_big$Theme1 == 'Partial', 'Theme1'] = 'Process'
  long_big[long_big$Theme2 == 'Unhelpful' & long_big$Theme1 == 'Partial', 'Theme1'] = 'People'
  #Ílong_big[long_big$Theme2 == 'Inadequate', 'Theme1'] = 'People'
  
  long_big$Soft_Delete = NULL
  
  #1
  #browser()
  
  # replicate a long_big data as long_big00, which has attributes uid, Theme1, Theme2, Theme3, Mapping
  long_big00 = long_big
  
  
  long_big00 %>% group_by(Mapping) %>% summarise(count = n_distinct(casenumber)) %>% ungroup %>% arrange(desc(count))
  
  # 22/01/2016 update: Capture Rate
  # subjective cap
  mat2.1 = mat2[, colnames(mat2) %in% c('friendly', "positive", "negative", "efficiency", "noteffciency", "easy", "hard", "profession", "unprofession", "competitive", "Inadequate")]
  sub_cap = mean(rowSums(mat2.1)>0)
  
  
  # objective_cap
  mat2.2 = mat2[, !colnames(mat2) %in% c('friendly', "positive", "negative", "efficiency", "noteffciency", "easy", "hard", "profession", "unprofession", "competitive", "Inadequate")]
  obj_cap = mean(rowSums(mat2.2)>0)
  
  no_dat = dat.verbatim[rowSums(mat2.2) <= 0 & rowSums(mat2.1) >0 ,  ]
  #write.csv(no_dat, "Production/Outputs/noncapture_objective.csv", row.names = FALSE)
  
  ns_dat = dat.verbatim[rowSums(mat2.1) <= 0 ,  ]
  #write.csv(ns_dat, "Production/Outputs/noncapture_subjective.csv", row.names = FALSE)
  
  # mapping cap
  top_map = long_big00 %>% group_by(Mapping) %>% 
    summarise(count = n()) %>% 
    arrange(desc(count)) %>% 
    top_n(10) %>% na.omit
  
  num_cap = long_big00 %>% filter(Mapping %in% top_map$Mapping) %>% distinct(casenumber) %>% summarise(count = n()) 
  map10_cap = num_cap$count/nrow(wide_big)
  
  top_map = long_big00 %>% group_by(Mapping) %>% 
    distinct(casenumber) %>% 
    summarise(count = n()) %>% 
    arrange(desc(count)) %>% 
    top_n(20) %>% na.omit
  long_big00 %>% filter(Mapping %in% top_map$Mapping) %>% distinct(casenumber) %>% summarise(count = n()) -> num_cap 
  map20_cap = num_cap$count/nrow(wide_big)
  
  
  nmat_dat = dat[ !dat$casenumber %in% long_big00$casenumber, ]
  #write.csv(nmat_dat, "Production/Outputs/notincludingindashboard.csv", row.names = FALSE)
  print(paste0("keyword capture rate:", kwd_cap))
  print(paste0("subjective keyword capture rate:", sub_cap))
  print(paste0("objective  keyword capture rate:", obj_cap))
  print(paste0("mapping capture rate:", map10_cap))
  
  
  
  
  

  
  