#' Cleaning data in suitable way
#' 
#' Because punctuation involved a lot extra information in survey data, 
#' we need a special care instead.
#' This function replace words by given dictionary pattern, and do special puntuation remove
#' Number is removed as well.
#' 
#' @param string Target String, currently this is not supporting any post-POS_tagged string.
#' @param mod dictionary for modification. The given pattern should be a vector 
#' has regular expression as pattern and the replacing words as names. Default is NULL.
#' @rm_puntc As some new algorithm (like RAKE) required punctuation or we want to remain special pattern
#' existed in the web (for example, bnz.com/homepage)
#' @return modified string 
#' 
#' 
#' @examples
#' string = "1. a/c's issue ($100,000.25) raised. Not-finished yet, 'question': couldn't we wait until boss confirm?! un-right a-DG U.S.A ...."
#' string
#' string2 = "channles(MIB,IB) works. creditcard/homeloan(personal). . ."
#' cleaning(string)
#' cleaning(cleaning(string))

cleaning <- function(string, mod = NULL, rm_puntc = TRUE) {
  
  ### replace words
  if (!is.null(mod)) {
    repl = names(mod)  
    for(i in 1:length(mod)){ 
      string = gsub(mod[i],
                  paste(" ",repl[i]," ",sep=""),
                  string,
                  ignore.case=True,
                  perl = TRUE) 
    }
    # space class with more than two space
    string = gsub("[[:space:]]{2,}"," ",string)
    # space in the start or end or a sentence
    string = gsub("[[:space:]]+$|^[[:space:]]+","",string) 
  }

  
  ### clean escaped characters, \\n -> ,
  string =  gsub("\\s+", " ", gsub("\\\\r|\\\\n|\\n|\\\\t", ", ", string))
  
  ### clean extra white spaces other textual anomalies that may cause errors
  string = scrubber(string)
  
  ### special rule "but/however" need to modify as a ".".
  string = gsub("\\bbut\\b|\\bhowever", ". ", string, ignore.case = TRUE)
  
  
  ### replace replace_contraction
  contrast = qdapDictionaries::contractions
  #contrast$contraction  = gsub("[[:punct:]]", "", contrast$contraction )
  #contrast$contraction = paste0("\\b", contrast$contraction)
  add_contrast = data.frame(contraction = c("haven't", "hadn't"), expanded = c("have not", "had not"))
  contrast = rbind(contrast, add_contrast)
  contrast = rbind(qdapDictionaries::contractions, contrast)  
  
  string = replace_contraction(string, contraction = contrast)
  
  
  ### removeNumber
  string = qdapRegex::rm_number(string)
  
  ### Add space after a comma
  string = comma_spacer(string)
  
  ### remove Abbreviations
  string = qdapRegex::rm_abbreviation(string)
  
  ### remove date
  string = qdapRegex::rm_date(string)
  
  ### remove email
  string = qdapRegex::rm_email(string)
  
  ### remove Non ASCII
  string = qdapRegex::rm_non_ascii(string)
  
  ### remove Phone
  string = qdapRegex::rm_phone(string)
  
  ### remove URL
  string = qdapRegex::rm_url(string)
  
#   ### remove emoticons
#   string = qdapRegex::rm_emoticon(string)
  
  ### remove tag
  string = qdapRegex::rm_tag(string)
  
  ### remove hash
  string = qdapRegex::rm_hash(string)
  
  ### remove braket
  string = gsub("[\\[\\]\\(\\)\\{\\}]", " ", string, perl = TRUE)
  
  ### removePunctuation
  if (rm_puntc) {
    string = gsub("(?<=de|un|in|im|ab|\\b\\w)(\\-)", "", string, perl = TRUE) # "-" in front of de|un|in|im
    string = gsub("\\-", " ", string)   # other "-" replace with  " "
    string = gsub("((?<=\\b\\w)(\\.|\\/)(?! ))+?", "", string, perl = TRUE) #A/c, U.S.A return AC, USA
    string = gsub("((?<=\\w{2})[/])", " ", string, perl = TRUE) ## AA/AB/AC is becoming AA AB AC
    string = gsub("\\'s ", " ", string, perl = TRUE)  ## xxx's return xxx
    string = gsub("(?![',.?!;])[[:punct:]]", "", string, perl = TRUE) # endmark keep.
    string = gsub("[[:punct:]]{2,}( |$)", ". ", string, perl = TRUE) # repeated punctuation become 1 full perior
  }
  string
}
