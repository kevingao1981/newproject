##Choose the table and columns you want to import into R


rdf_sft_cases <- sqlQuery(Impala, 
                          "SELECT
                          casenumber,
                          createddate,
                          description,
                          customer_number__c,
                          (CASE 
                          WHEN customer_segment_formula__c LIKE '%Retail%' then 'Retail' 
                          WHEN customer_segment_formula__c LIKE '%Small Business%' then 'Small Business' 
                          WHEN customer_segment_formula__c LIKE '%Business%' then 'Business'
                          WHEN customer_segment_formula__c LIKE '%Commercial%' then 'Commercial'
                          WHEN customer_segment_formula__c LIKE '%Corporate%' then 'Corporate'
                          Else 'Other'
                          END) 
                          AS Customer_Segment_MD, 
                          category__c,
                          case_type__c,
                          days_to_resolve__c,
                          priority,
                          cost_to_resolve__c
FROM z3_raw.sft_case
                          
                          WHERE

                          case_type__c in ('Complaint')

                          AND

                          category__C NOT IN ('Credit Cards', 'Credit Card')
                          
                          Having Customer_Segment_MD NOT IN ('Retail', 'Other', 'Corporate')
                          Limit 10")
                          
summary(rdf_sft_cases)
