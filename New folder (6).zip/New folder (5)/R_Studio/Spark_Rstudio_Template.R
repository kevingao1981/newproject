#remove table and release memory

rm(list = ls())
gc()

#install packages
library(RODBC)
library(DBI) 
library(sparklyr)

#SQL datasource
user <- as.numeric(system('echo $USER', intern = TRUE)) 
system(paste0("kinit -kt /etc_cloudera/user_home/", user,"/", user, ".keytab ", user)) 
Impala <- RODBC::odbcConnect("Impala")

sc <- spark_connect(master="yarn-client", version = "2.2.0", config = list(
  spark.yarn.keytab = "/etc_cloudera/user_home/771219/771219.keytab",
  spark.yarn.principal = "771219@BNZNAG.NZ.THENATIONAL.COM",
  sparklyr.shell.keytab = "/etc_cloudera/user_home/771219/771219.keytab",
  sparklyr.shell.principal = "771219@BNZNAG.NZ.THENATIONAL.COM"
))


mydata <- sqlQuery(Impala, "SELECT * FROM z0_strategy.kg_future_value_test")


#Select the column from dataset
mydata1<- subset(mydata,select = c("sp_foot","revenue"))
table(mydata1$revenue)
mydata1<-mydata[complete.cases(mydata),]

#Correlation test
cor(mydata1)

#Kmeans
#standardized data
mydata1<-scale(mydata1)
#cluste 6 group
fit=kmeans(mydata1,6)
#get summary of each group
aggregate(mydata1,by=list(fit$cluster),FUN = mean)
#output to dataframe with cluster number
output <- data.frame(mydata,fit$cluster)

#write table to hadoop
dbWriteTable(sc, "z0_strategy.S35_var_contribution", mydata)

# close spark connection
spark_disconnect(sc)
odbcClose(Impala)

