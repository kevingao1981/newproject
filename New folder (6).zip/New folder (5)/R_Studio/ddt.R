#' Build data frame of Document(Row), Term(Column) structure
#' 
#' A short cut to control we are using a consistent function.
#' dtm only did stripWhitespace, Bind removePunctuation, removeStopwords and stemDocument only.
#' Thus, please remember to call the cleaning() on the data if you need semantic effect...
#' This function is converting text to bag-of-words model in data frame structure. 
#' 
#' @param string Target String, currently this is not supporting any post-POS_tagged string.
#' @param weight Weighting method, it is an interface to tm weighting. Default is weightBin
#' @param stopw Stopwords,  you can assign a vector of words and removed these words. Default is tm::stopwords("en")
#' @param dict Dictionary, you can assign a vector of words and only return these words. Default is Null.
#' @param min.support The number of document frequency for each terms, 
#' assign a numeric decimal is removeSparse, an integer is just colSums, Default is 1L, and uses L to indicate integer
#' @param corpus.only just return corpus only. Default is FALSE.
#' 
#' @return A data frame class of DocumentTermMatrix(string) or just processing corpus 
#' 
#' 


ddt <- function(string, weight = weightBin, stopw = stopwords("en") ,
                dict = NULL, min.support = 2L, corpus.only = FALSE, stem = FALSE) {

  
  cpp = Corpus(VectorSource(tolower(string)))
  cpp = tm_map(cpp, removeWords, stopw)
  cpp = tm_map(cpp, removePunctuation)
  cpp = tm_map(cpp, removeNumbers)
  cpp = tm_map(cpp, stripWhitespace)
  if (stem)
    cpp = tm_map(cpp, stemDocument)
 
  dtm = DocumentTermMatrix(cpp, control = list(tokenize = MC_tokenizer,  weighting = weight,
                                               wordLengths = c(2,Inf),
                                               dictionary = dict))

  if (!is.integer(min.support) & (min.support >0 & min.support < 1)){
    
    dtm = removeSparseTerms(dtm, min.support)
    dtm = as.data.frame(data.matrix(dtm))
    
  }else {
    
    dtm = as.data.frame(data.matrix(dtm))
    dtm = dtm[, colSums(dtm) >= min.support]
    
  }
  
  dtm
}


ddt2 <- function(string, weight = weightBin, stopw = stopwords("en") ,
                dict = NULL, min.support = 2L, corpus.only = FALSE) {
  
  
  cpp = Corpus(VectorSource(tolower(string)))
  cpp = tm_map(cpp, removeWords, stopw)
  cpp = tm_map(cpp, removePunctuation)
  cpp = tm_map(cpp, removeNumbers)
  cpp = tm_map(cpp, stripWhitespace)
  cpp = tm_map(cpp, stemDocument)
  
  dtm = DocumentTermMatrix(cpp, control = list(weighting = weight, 
                                               stemming = TRUE,
                                               wordLengths = c(2,Inf),
                                               dictionary = dict))
  dtm = as.data.frame(data.matrix(dtm))
  dtm
}
