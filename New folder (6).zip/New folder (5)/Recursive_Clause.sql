declare @mag_id as integer

set @mag_id = 801;

with temp_table(employee_id,depth) as 
(
SELECT employee_id,0 as depth
FROM dbo.Recursive 
WHERE manager_id = @mag_id
union all
select b.employee_id, a.depth+1 as newdepth
from temp_table a
inner join dbo.Recursive b
on a.employee_id = b.manager_id
)
select * from temp_table order by employee_id
