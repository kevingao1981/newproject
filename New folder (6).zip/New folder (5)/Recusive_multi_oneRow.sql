/*
Combine multi rows into one based on row_num asc order
*/
Drop table if exists [Chapter3].[dbo].[Multi_into_One]

SELECT [Employee_id]
	,'A' + [Employee_id] as [A_Employee_id] 
      ,[manager_id]
	  ,'A' + [Employee_id] as Concate_group 
	  ,ROW_NUMBER() over (partition by [manager_id] order by [Employee_id]) as row_num
	  --,count(*) over (partition by [manager_id]) as max_row_num
Into [Chapter3].[dbo].[Multi_into_One]
FROM [Chapter3].[dbo].[Recursive]
go

Alter table [Chapter3].[dbo].[Multi_into_One]
alter column Concate_group nvarchar(max)

with rec_test ([manager_id], Concate_group, row_num)
as
(
select [manager_id]
,Concate_group
,row_num
from [Chapter3].[dbo].[Multi_into_One]
where row_num = 1

union all

select b.[manager_id],
concat(b.Concate_group,'||',a.Concate_group),
b.row_num+1
from [Chapter3].[dbo].[Multi_into_One] a
inner join rec_test b
on a.manager_id = b.manager_id
and a.row_num = b.row_num+1
)
select *
from 
(
select *,
count(*) over (partition by [manager_id]) as max_row_num
from rec_test
)x
where x.row_num = x.max_row_num
--where row_num = max_row_num

go

/*
Combine multi rows into one based on row_num desc order
*/
Drop table if exists [Chapter3].[dbo].[Multi_into_One]

SELECT [Employee_id]
	,'A' + [Employee_id] as [A_Employee_id] 
      ,[manager_id]
	  ,'A' + [Employee_id] as Concate_group 
	  ,ROW_NUMBER() over (partition by [manager_id] order by [Employee_id]) as row_num
	  ,count(*) over (partition by [manager_id]) as max_row_num
Into [Chapter3].[dbo].[Multi_into_One]
FROM [Chapter3].[dbo].[Recursive]
go

Alter table [Chapter3].[dbo].[Multi_into_One]
alter column Concate_group nvarchar(max)

with rec_test ([manager_id], Concate_group, row_num)
as
(
select [manager_id]
,Concate_group
,row_num
from [Chapter3].[dbo].[Multi_into_One]
where row_num = max_row_num

union all

select b.[manager_id],
concat(b.Concate_group,'||',a.Concate_group),
b.row_num-1
from [Chapter3].[dbo].[Multi_into_One] a
inner join rec_test b
on a.manager_id = b.manager_id
and a.row_num = b.row_num-1
)
select *
from rec_test
where row_num =1
--where row_num = max_row_num





