
# coding: utf-8

# In[187]:


import csv
from decimal import Decimal
#csv: Branch_A, Branch_B, counts of customers.
#If Branch_A = Branch_B => total number of visitors of A.
#If Branch_A != Branch_B => number of customers who visited A and B.

# transform the dataset into graph G
# filePath is path to the file
# method is graph type & properties
# Threshold is an integer such that edge exists if the weight >= threshold. 
# if threshold = 1 => all edges are included
def readDataToGraph(filePath, method, threshold):
    with open (filePath) as dataFile:
        try:
            reader = csv.reader(dataFile, delimiter=',')
            if (method == 'Simplest'): graph = generateSimpleGraph(reader, threshold)
            elif (method == 'WeightedLoops'): graph = generateWeightedLoops(reader, threshold)
            elif (method == 'DirectedWeighted'): graph = generateDirectedWeighted(reader, threshold) 
            else: print 'ERROR: this method does not exist'
        finally:
            dataFile.close()          
    return graph;


   


# In[188]:


#G = (V, E): there exists an edge if counts of customer >= threshold. No loops. No weights
def generateSimpleGraph(reader, threshold):
    graph = Graph()
    edges = set()
    nodes = set()
    for row in reader:
        edge = (row[0], row[1])
        nodes.add(row[0])
        if (row[0] != row[1]) and (int(row[2])>= threshold):
            edges.add(edge)
    graph.add_vertices(nodes)
    graph.add_edges(edges)
    return graph;

#G = (V, E, W): there exists an edge if counts of customers >= threshold. Weight = counts of customers.
def generateWeightedLoops(reader, threshold):
    graph = Graph(loops = True, weighted=True)
    edges = set()
    nodes = set()
    for row in reader:
        edge = (row[0], row[1], int(row[2]))
        nodes.add(row[0])
        if (int(row[2])>= threshold):
            edges.add(edge)
    graph.add_vertices(nodes)
    graph.add_edges(edges)
    return graph; 

#directed graph G = (V, E, W): Weight        TODO! NO LOOPS for the moment     TODO! RELATIVE THRESHOLDS!
#0 < threshold < 1 
def generateDirectedWeighted(reader, threshold):
    graph = DiGraph(weighted = True)
    edges = set()
    weighted_nodes = dict()
    weighted_edges = set()
    for row in reader:
        if (row[0] == row[1]):
            weighted_nodes[row[0]] = int(row[2])
            graph.add_vertex(row[0])
        else:
            edges.add((row[0], row[1], int(row[2])))
    
    for edge in edges:
        weight = round(Decimal(float (edge[2])/ float (weighted_nodes[edge[0]])),3)
        if(weight>= threshold):
            weighted_edge = (edge[0], edge[1], weight)
            weighted_edges.add(weighted_edge)
            graph.add_edge(weighted_edge)
    return graph; 
    


# In[189]:


from sage.graphs.connectivity import connected_components

#output some statistics about each connected component in the graph
def analyzeSubNets(graph):
    subNets = graph.connected_components_subgraphs()
    print 'Number of Subnets: ' + str(len(subNets))
    standAlone = list()
    for subnet in subNets:
        if (len(subnet.vertices()))> 1:
            diam = subnet.diameter()
            rad = subnet.radius()
            branchesCenter = subnet.center()
            print 'Number of branches: ' + str(len(subnet.vertices()))
            print 'radius: ' + str(rad)
            print 'diameter: ' + str(diam)
            print 'Branches in the center: ' + str(branchesCenter)
            print 'Branches with largest degree: ' + str(getMaxDegreeNodes(subnet))
            print 'Max Betweenness: '+ str(getMaxBetweenness(subnet))
            if (subnet.weighted()):
                print 'Max Centrality Closeness: ' + str(getMaxCentralityCloseness(subnet, True))
                subnet.show(edge_labels=True)
            else: 
                print 'Max Centrality Closeness: ' + str(getMaxCentralityCloseness(subnet, False))
                subnet.show()
            #subnet.show()
        else: 
            standAlone += subnet.vertices()
    print str(len(standAlone)) + ' standalone Branches: ' + str(standAlone) 


# In[190]:


def getMaxDegreeNodes(graph):
    maxDegree = max(graph.degree())
    vertList = [v for v in graph.vertices() if graph.degree(v) == maxDegree]
    return (maxDegree, vertList);

#works better but returns only one element
def getMaxDegree(graph):
    xs = map(lambda node: (node, graph.degree(node)), graph.vertices())
    maxDegree = max(xs, key = lambda t: t[1])
    return maxDegree;

def getMaxBetweenness(graph):
    xs = map(lambda node: (node, graph.centrality_betweenness(weight = True)[node]), graph.vertices())
    return max(xs, key = lambda t: t[1]);

def getMaxCentralityCloseness(graph, by_weight):
    xs = map(lambda node: (node, graph.centrality_closeness(node, by_weight)), graph.vertices())
    return max(xs, key = lambda t: t[1]);

#print getMaxDegreeNodes(net)
#print getMaxDegree(net)
#print getMaxCentralityCloseness(net1, False)
#print getMaxCentralityCloseness(net2, True)


# In[5]:


#readDataToGraph(net, "graph_data_short.csv")
net1 = readDataToGraph("graph_data.csv", 'Simplest', 500)
net2 = readDataToGraph("graph_data.csv", 'WeightedLoops', 500)
net3 = readDataToGraph("graph_data.csv", 'DirectedWeighted', 0.2)
print 'Simplest:'
print 'Number of branches Simplest: ' + str(len(net1.vertices()))
print 'Average degree: ' + str(int(net1.average_degree()))
print 'Weighted Loops: '
print 'Number of branches: ' + str(len(net2.vertices()))
print 'Average degree: ' + str(int(net2.average_degree()))
print ''
print 'Directed Weighted: '
print 'Number of branches: ' + str(len(net3.vertices()))
print 'Average degree: ' + str(int(net3.average_degree()))
print ''


# In[422]:


analyzeSubNets(retail_net)


# In[423]:


#net3 = readDataToGraph("graph_data.csv", 'DirectedWeighted', 0.2)
net3 = readDataToGraph(".sage/retail network.csv", 'DirectedWeighted', 0.2)
analyzeSubNets(net3)


# In[82]:


net1 = readDataToGraph("graph_data.csv", 'Simplest', 500)
net2 = readDataToGraph("graph_data.csv", 'WeightedLoops', 500)
#net1.centrality_betweenness()
print getMaxBetweenness(net1)
print getMaxBetweenness(net2)
print getMaxCentralityCloseness(net1, False)
print getMaxCentralityCloseness(net2, True)


# In[191]:


#Find an edge with the max weight (ratio = percentage of customers) from edges_set
#nodes_dict = (BranchA: weightA) - total number of visits of BranchA
#edges_set = (BranchA, BranchB, weight)
#If there are two nodes with the max weight => choose the node that has fewer connections
#If the same node has the same dependency level from several other nodes => it does not belong to any cluster

def getMaxRatioEdge(nodes_dict, edges_set):
    xs = map(lambda edge: (edge, float(edge[2])/float(nodes_dict[edge[0]])), edges_set)
    mRat = max(xs, key = lambda t: t[1])
    maxList = [ee[0] for ee in xs if ee[1] == mRat[1]]
    if len(maxList) == 1: return mRat
    elif len(maxList) == 0: print 'ERROR: The list is empty!'
    else:
        print 'WARNING: there are ' + str(len(maxList)) + ' edges with the max dependency rate'
        xss = map(lambda edge: (edge, len([e for e in edges_set if  e[0] == edge[0]])), maxList)
        minCon = min(xss, key = lambda t: t[1])
        minConList = [ee[0] for ee in xss if ee[1] == minCon[1]]
        nodesA = list(set([e[0] for e in minConList]))
        
        # one edge has nodeA with min connections => return that edge
        if len(minConList) == 1: return (minCon[0], mRat[1])
        
        # more than one edge but they are all have only a single connection => parse them one by one
        elif minCon[1] == 1:
            print 'Leaves: ' + str(minConList)
            return (minCon[0], mRat[1])
        
        # nodeA has the same dependency level from several nodes => nodeA does not belong to any cluster
        # unless all nodeBs already belong to the same cluster 
        elif len(nodesA) == 1:
            nodesB = list(set([e[1] for e in minConList]))
            print 'WARNING: ' + str(nodesA) + ' has the same dependency rate from ' + str(len(minConList)) + ' other branches ' + str(nodesB)
            return (nodesA, nodesB)
        
        #Some other case: let it fail: to get this error, try Wholesale_net = 10 x 0.5
        else:
            print 'ERROR: there are ' + str(len(minConList)) + ' edges with ' + str(minCon[1]) + ' connections each'   
            return (minCon[0], mRat[1])
            


#sateliteClusters = getSateliteClusters(net2, 0.7)


# In[192]:


#if all branches B belong to the same cluster, i.e. cluster key is the same for all nodes B 
def processingWeirdCases(weird_cases, clusters):
    for nodeA, nodesB in weird_cases.items():
        clusterKey = []
        for b in nodesB:
            bKey = set({k:v for k, v in clusters.items() if b in v}.keys())
            clusterKey = list(set(clusterKey).union(bKey))
            if (bKey == []) or (bKey is None) or (len(clusterKey) != 1):
                clusterKey = []
                break;
        
        if (clusterKey == []): print str(nodeA) + " is not a satelite"
        else:
            print str(nodeA) + ' is a satelite of ' + str(clusterKey)
            
            #nodeA is the center of existing cluster => add all nodes to clusterKey and remove it from dictionary
            if (nodeA in clusters):
                clusters[clusterKey[0]]+=(clusters[nodeA])
                del clusters[nodeA]
                    
            #nodeA is not the center => add it to the cluster[clusterKey] 
            else:
                clusters[clusterKey[0]].append(nodeA)    
    return clusters;


# In[193]:


#Satelites: nodes that gravitate towards others: high rate of customers in branchA visited branchB
#graph = (G,V,E) is an undirected graph with loops
#0 < threshold < 1 
def getSateliteClusters(graph, threshold):
    clusters = dict()
    
    #w_nodes = (branch name, number of customers)   
    w_nodes = dict()
    #w_edges = (branch name A, branch name B, number of customers A&B)
    w_edges = dict()
    
    #create a dictionary of weird cases: when branch A has the same dependency rate from two or more other branches.
    #Process them at the end when other cases are resolved: 
    #if all B1, B2, ... belong to the same cluster => add A to that cluster
    #otherwise A does not belong to any cluster
    #weird_cases = (nodeA: [node B1, node B2, ...]])
    weird_cases = dict()

    #fill the dictionary w_nodes using the weight on the loops
    for i in graph.loop_edges():
        #loop_edge = (branch A, branch A, weight) => w_node = (branch A, weight)
        w_nodes[i[0]] = i[2]
    edgesNoLoops = set(graph.edges()) - set(graph.loop_edges())
    (edge, maxRatio) = getMaxRatioEdge(w_nodes, edgesNoLoops)
    #nodeA is dominated; nodeB is the cluster center
    (nodeA, nodeB, weight) = edge
    while maxRatio >= threshold:
        
        flattenVals = [item for sublist in clusters.values() for item in sublist]
        
        #if nodeB already is a center of a cluster => add nodeA (and its cluster) to the cluster nodeB
        if nodeB in clusters:          
            #print nodeB + ' is alredady in the cluster (A)'
            if (nodeA in clusters):
                clusters[nodeB]+=(clusters[nodeA])
                del clusters[nodeA]
            else: clusters[nodeB].append(nodeA)      
        
        #if nodeB belongs to a cluster => find the center of the cluster it belongs and add nodeA to that cluster
        elif nodeB in flattenVals: 
            clusterKey = {k:v for k, v in clusters.items() if nodeB in v}.keys()[0]
            if (nodeA in clusters):
                clusters[clusterKey]+=(clusters[nodeA])
                del clusters[nodeA]
            else: clusters[clusterKey].append(nodeA)
            #print nodeB + ' is already in the cluster (C)'    
        
        else:
            clusters[nodeB] = [nodeA, nodeB]
            if (nodeA in clusters):
                clusters[nodeB]+=(clusters[nodeA])
                del clusters[nodeA]
        
        del w_nodes[nodeA]
        edgesNoLoops = [e for e in  edgesNoLoops if e[0] != nodeA]
        
        while true:
            nextEdge = getMaxRatioEdge(w_nodes, edgesNoLoops)
            try: 
                (edge, maxRatio) = nextEdge
                (nodeA, nodeB, weight) = edge
                break;
            except ValueError: 
                nodeA = nextEdge[0][0]
                nodesB = nextEdge[1]
                weird_cases[nodeA] = nodesB
                #print 'nodesB: ' + str(nodesB)
                 
                del w_nodes[nodeA]
                edgesNoLoops = [e for e in  edgesNoLoops if e[0] != nodeA]
            #except TypeError:
                #TODO last case
       
    #process the weird cases:
    clusters = processingWeirdCases(weird_cases, clusters)
    print 'number of clusters: ' + str(len(clusters))
    print clusters
    return clusters;

#sateliteClusters = getSateliteClusters(net2, 0.7)


# In[194]:


from sage.plot.colors import rainbow

def plotSubgraphs(graph, clusters):
    subNets = graph.connected_components_subgraphs()
    print ''
    standAlone = list([subN.vertices() for subN in subNets if len(subN.vertices()) == 1])
    print 'Number of Connected Components: ' + str(len(subNets) - len(standAlone))
    print str(len(standAlone)) + ' standalone Branches: ' + str(standAlone); 
    standAlone = list()
    for subnet in subNets:
        verts = subnet.vertices()
        if (len(verts))> 1:
            keysInSubnet = set(verts).intersection(clusters.keys())  #TODO: MAKE IT NICER
            clustersInSubnet = {k: clusters.get(k) for k in keysInSubnet}
            R = rainbow(len(clustersInSubnet))
            c = 0
            colorDict = dict()
            for clusterVals in clustersInSubnet.values(): 
                colorDict[R[c]] = clusterVals
                c+=1
            
            #print colorDict
            flattenVals = [item for sublist in clustersInSubnet.values() for item in sublist]
            flattenVals = list(set(flattenVals) - set(clustersInSubnet.keys()))
            subnet.graphplot(layout = "spring")
            
            #Define figure size depending on number of vertices in the subnetwork
            if (len(verts)) > 100: f_size = 18
            elif (len(verts) > 70 and len(verts) <= 100): f_size = 15
            elif (len(verts) > 50 and len(verts) <= 70): f_size = 12
            elif (len(verts) > 20 and len(verts) <= 50): f_size = 10
            elif (len(verts) > 10 and len(verts) <= 20): f_size = 6
            elif (len(verts) > 5 and len(verts) <= 10): f_size = 4
            else: f_size = 2
                       
            #subnet.show(edge_labels=True, vertex_colors = colorDict, loop_size = .05)
            subnet.show(edge_labels = False, vertex_colors = colorDict, loop_size = 0, figsize = f_size)
        else: 
            standAlone += subnet.vertices()

    print str(len(standAlone)) + ' standalone Branches: ' + str(standAlone); 


# In[11]:


aggregated_net = readDataToGraph(".sage/aggregated network.csv", 'WeightedLoops', 500)    
print len(aggregated_net.vertices())
sateliteClusters = getSateliteClusters(aggregated_net, 0.27)
plotSubgraphs(aggregated_net, sateliteClusters)


# In[64]:


wholesale_net = readDataToGraph(".sage/wholesale network.csv", 'WeightedLoops', 20)    
print len(wholesale_net.vertices())
sateliteClusters = getSateliteClusters(wholesale_net, 0.67)
plotSubgraphs(wholesale_net, sateliteClusters)


# In[212]:


partners_net = readDataToGraph(".sage/partners network.csv", 'WeightedLoops', 150)
print len(partners_net.vertices())
sateliteClusters = getSateliteClusters(partners_net, 0.3)
plotSubgraphs(partners_net, sateliteClusters)


# In[201]:


retail_net = readDataToGraph(".sage/retail network.csv", 'WeightedLoops', 100)    
print len(retail_net.vertices())
sateliteClusters = getSateliteClusters(retail_net, 0.1)
plotSubgraphs(retail_net, sateliteClusters)


# In[214]:


smallBus_net = readDataToGraph(".sage/SBH network.csv", 'WeightedLoops', 54)   
print len(smallBus_net.vertices())
sateliteClusters = getSateliteClusters(smallBus_net, 0.2)
plotSubgraphs(smallBus_net, sateliteClusters)


# In[28]:


def printAverageDegrees(threshold):
    aggregated_net = readDataToGraph(".sage/aggregated network.csv", 'WeightedLoops', threshold)  
    smallBus_net = readDataToGraph(".sage/SBH network.csv", 'WeightedLoops', threshold)
    retail_net = readDataToGraph(".sage/retail network.csv", 'WeightedLoops', threshold)   
    partners_net = readDataToGraph(".sage/partners network.csv", 'WeightedLoops', threshold)
    wholesale_net = readDataToGraph(".sage/wholesale network.csv", 'WeightedLoops', threshold)   
    # avg_degree - 1 to exclude the loops
    print 'Aggregated: ' + str(float(aggregated_net.average_degree()) - 1)    
    print 'Small Business Hub: ' + str(float(smallBus_net.average_degree()) - 1)
    print 'Retail: ' + str(float(retail_net.average_degree()) - 1)
    print 'Partners: ' + str(float(partners_net.average_degree()) - 1)
    print 'Wholesale: ' + str(float(wholesale_net.average_degree()) - 1);
        
printAverageDegrees(150)    


# In[29]:


def printComponents(threshold, graph):
    subNets = graph.connected_components_subgraphs()
    standAlone = list([subN.vertices() for subN in subNets if len(subN.vertices()) == 1])
    print 'Number of Connected Components: ' + str(len(subNets) - len(standAlone))
    print str(len(standAlone)) + ' standalone Branches: ' + str(standAlone); 

def getComponents(thresholdRange):
    for threshold in thresholdRange:
        print 'threshold: ' + str(threshold)
        print "Aggregated: "
        aggregated_net = readDataToGraph(".sage/aggregated network.csv", 'WeightedLoops', threshold)  
        printComponents(threshold, aggregated_net)
        print "Small Business: "        
        smallBus_net = readDataToGraph(".sage/SBH network.csv", 'WeightedLoops', threshold)
        printComponents(threshold, smallBus_net)
        
        retail_net = readDataToGraph(".sage/retail network.csv", 'WeightedLoops', threshold)   
        printComponents(threshold, retail_net)
        
        partners_net = readDataToGraph(".sage/partners network.csv", 'WeightedLoops', threshold)
        printComponents(threshold, partners_net)
        
        wholesale_net = readDataToGraph(".sage/wholesale network.csv", 'WeightedLoops', threshold) 
        printComponents(threshold, wholesale_net);
    
thresholdRange = (1, 10, 20, 30, 40, 50, 75, 100, 150)
getComponents(thresholdRange)


# In[61]:


picGraph = DiGraph({'A': ['B', 'D', 'E', 'C'], 'B': ['A'], 'D': ['A'], 'E': ['A'], 'F': ['A']})
picGraph.plot()
l2 = ['B', 'C', 'D', 'E', 'F']
l1 = ['A']
picGraph.show(edge_labels = False, vertex_colors = {'aqua': l2, 'red': l1}, figsize = 5)

satGraph = DiGraph({'A': ['B', 'C'], 'D': ['A'], 'B':['A', 'C'] })
l2 = ['B', 'C', 'A']
l1 = ['D']
satGraph.plot()
satGraph.show(edge_labels = False, vertex_colors = {'aqua': l2, 'red': l1}, figsize =4)


# In[24]:


exampleGraph = Graph({'A':[], 'B':[], 'C':[], 'D':[], 'E':[], 'F':[]})
exampleGraph.plot()
myBranches = exampleGraph.vertices()
exampleGraph.show(edge_labels = False, vertex_colors = {'aqua': myBranches}, layout = 'circular', figsize = 3, save_pos = True)

exampleGraph.add_edges([('A', 'C'), ('A', 'D'), ('C', 'D')])
#exampleGraph.plot()
annaBranches = ['A', 'C', 'D']
exampleGraph.show(vertex_colors = {'aqua'}, figsize = 3)

exampleGraph.add_edges([('B', 'D'), ('B', 'E'), ('D', 'E'), ('B', 'C'), ('D', 'C'), ('C', 'E')])
bobBranches = ['B', 'D', 'E', 'C']
exampleGraph.show(vertex_colors = {'aqua'}, figsize = 3)

exampleGraph.add_edges([('E', 'F')])
carlBranches = ['E', 'F']
exampleGraph.show(vertex_colors = {'aqua': [v for v in myBranches if v not in carlBranches], 'red': carlBranches}, figsize = 3)


# In[36]:


exampleGraph2 = graphs.CompleteGraph(100)

exampleGraph2 = graphs.RandomBarabasiAlbert(100,10)
exampleGraph2.plot()
exampleGraph2.show(edge_labels = False, vertex_colors = {'aqua'}, layout = 'spring', save_pos = True)


# In[185]:


satGraph = DiGraph()
#satGraph.add_edges([('1200', '1000', 200), ('1200', '700', 100), ('1200', '800', 150), ('1000','700', 100), ('400', '700', 150), ('600', '700', 120) ])
edges = [('D', 'A'), ('A', 'B'), ('B', 'A'), ('C', 'B'), ('C', 'A'), ('E', 'C'), ('C', 'E'), ('C', 'F')]
satGraph.add_edges(edges)
satGraph.plot()
satGraph.show(edge_labels = False, vertex_colors = 'aqua', figsize =5)


# In[154]:


satGraph = DiGraph()
edges= [('1200', '1000', round(Decimal(float(200)/1200), 2)), ('1000', '1200', round(Decimal(float(200)/1000),2))]
edges += [('700', '1200', round(Decimal(float(100)/700),2))]
edges += [('1200', '800', round(Decimal(float(150)/1200),2)), ('800', '1200', round(Decimal(float(150)/800),2))]
edges += [('700','1000', round(Decimal(float(100)/700),2))]
edges += [('400', '700', round(Decimal(float(150)/400), 2)), ('700', '400', round(Decimal(float(150)/700), 2))]
edges += [('600', '700', round(Decimal(float(120)/600), 2)), ('700', '600', round(Decimal(float(120)/700), 2))] 
satGraph.add_edges(edges)
satGraph.plot()
satGraph.show(edge_labels = True, vertex_colors = 'aqua', figsize =7)


# In[171]:


satGraph = DiGraph()
edges= [('1200', '1000', round(Decimal(float(200)/1200), 2)), ('1000', '1200', round(Decimal(float(200)/1000),2))]
edges += [('700', '1200', round(Decimal(float(100)/700),2))]
edges += [('800', '1200', round(Decimal(float(150)/800),2))]
edges += [('700','1000', round(Decimal(float(100)/700),2))]
edges += [('400', '700', round(Decimal(float(150)/400), 2)), ('700', '400', round(Decimal(float(150)/700), 2))]
edges += [('600', '700', round(Decimal(float(120)/600), 2)), ('700', '600', round(Decimal(float(120)/700), 2))] 
satGraph.add_edges(edges)
satGraph.plot()
satGraph.show(edge_labels = True, vertex_colors = 'aqua', figsize =7)


# In[163]:


random_example = graphs.RandomGNP(100, 0.1)
subgraph1 = random_example.subgraph(list(range(0,50)))
subgraph2 = random_example.subgraph(list(range(50,70)))
subgraph3 = random_example.subgraph(list(range(70,790)))
subgraph4 = random_example.subgraph(list(range(90,100)))
#random_example.show(edge_labels = False, vertex_colors = {'aqua'}, layout = 'spring', save_pos = True)
subgraph1.show(edge_labels = False, vertex_colors = {'aqua'}, layout = 'spring', save_pos = True)
subgraph2.show(edge_labels = False, vertex_colors = {'aqua'}, layout = 'spring', save_pos = True)
subgraph3.show(edge_labels = False, vertex_colors = {'aqua'}, layout = 'spring', save_pos = True)
subgraph4.show(edge_labels = False, vertex_colors = {'aqua'}, layout = 'spring', save_pos = True)

