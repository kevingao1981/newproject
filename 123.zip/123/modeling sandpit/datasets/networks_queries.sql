-- Generating networks datasets: Partner, Wholesale, Retail
with t1 as (
    select distinct A.auth_customer_no as cust, Cust.retailer as segment, concat(A.branch_id, A.location_suffix) as branch_id,
        A.branch_location_name as branch_name
    from z1_digital.tcs_over_the_counter_events as A
    LEFT JOIN z1_strategy.car_customer_profile_m as Cust on A.auth_customer_no = Cust.custno
    where A.dim_month_key between 201710 and 201809
        and A.auth_customer_no is not null
        and A.event_type not in ('BCD', 'Transfer (InterAct)')
        and A.branch_location_name not in ('GIS TEST BRANCH', 'GIS Airport Test Branch')
        and cust.retailer in ('PARTNER','WHOLESALE', 'RETAIL')
        AND truncate(Cust.snapshot_date_key/100) = A.dim_month_key
),   
t2 as (
    select * from t1
)
select  t1.branch_name as branch_name_A, t2.branch_name as branch_name_B, count(distinct t1.cust) as cust_cnt, t1.segment
from t1, t2
where t1.cust  = t2.cust
group by t1.branch_name, t2.branch_name, t1.branch_id, t2.branch_id, t1.segment
order by t1.branch_name, t2.branch_name;