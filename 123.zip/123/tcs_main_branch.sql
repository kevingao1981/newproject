/*
OTC events per customer per branch with labeling branch as 'main'
Assumptions: 
1. Main branch is the branch that customer visited most times. 
   If two branches have the same number of visits -- > no main branch
2. Only customers that identified themselves are included
3. Amount of transaction is approximation only: sum(amount)/2
4. FY 2017-18
5. BCD and Transfer (InterAct) are excluded 
*/
select detail.*, 
case when non_dup_maxes.max_visit_cnt is null then 0 
     when count() over (partition by detail.custno, branch_address) = non_dup_maxes.max_visit_cnt then 1 
     else 0 
end as main_branch
from 
    (select TSC.auth_customer_no as custno, TSC.event_sequence_no as event_ID, TSC.event_type,
            TSC.branch_id, TSC.branch_name, TSC.branch_address,
            sum(TSC.amount)/2 as total_amount, sum(TSC.cash_total) as cash_amount,
            cust.segment, cust.custtype 
        from z1_digital.tcs_over_the_counter_events as TSC
        JOIN z1_strategy.car_customer_profile_m as Cust on TSC.auth_customer_no = Cust.custno
        where TSC.dim_month_key between 201710 and 201809
        and TSC.auth_customer_no is not null
        and TSC.event_type not in ("BCD", "Transfer (InterAct")
        AND cust.segment is not null
        and truncate(Cust.snapshot_date_key/100)  = TSC.dim_month_key     
        GROUP BY TSC.auth_customer_no, TSC.event_sequence_no, TSC.event_type,
        TSC.branch_name, TSC.branch_id, TSC.branch_address, cust.custtype, cust.segment
        ORDER BY TSC.auth_customer_no
    ) as detail 
LEFT JOIN
(
  select custno, max(visit_cnt) as max_visit_cnt
  from (
    select custno, branch_id, branch_name, branch_address, visit_cnt, rank() over (partition by custno order by visit_cnt desc) as visit_rank
    from (
       select custno, branch_id, branch_name, branch_address, count(*) as visit_cnt
       from 
       (select TSC.auth_customer_no as custno, TSC.event_sequence_no as event_ID, TSC.event_type,
            TSC.branch_id, TSC.branch_name, TSC.branch_address,
            sum(TSC.amount)/2 as total_amount, sum(TSC.cash_total) as cash_amount,
            cust.segment, cust.custtype 
        from z1_digital.tcs_over_the_counter_events as TSC
        JOIN z1_strategy.car_customer_profile_m as Cust on TSC.auth_customer_no = Cust.custno
        where TSC.dim_month_key between 201710 and 201809
        and TSC.auth_customer_no is not null
        and TSC.event_type not in ("BCD", "Transfer (InterAct)")
        AND cust.segment is not null
        and truncate(Cust.snapshot_date_key/100)  = TSC.dim_month_key     
        GROUP BY TSC.auth_customer_no, TSC.event_sequence_no, TSC.event_type,
        TSC.branch_name, TSC.branch_id, TSC.branch_address,
        cust.custtype, cust.segment
        ORDER BY TSC.auth_customer_no
       ) as detail 
       group by custno, branch_id, branch_name, branch_address
    ) as counts
  ) as ranks
  where visit_rank = 1
  group by custno
  having count(*) = 1
) as non_dup_maxes
on  detail.custno = non_dup_maxes.custno;